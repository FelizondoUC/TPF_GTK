/*
 * humano.h
 *
 *  Created on: 22 oct. 2023
 *      Author: lp1-2023
 */

#ifndef HUMANO_H_
#define HUMANO_H_

void juegaHumano();

#endif /* HUMANO_H_ */

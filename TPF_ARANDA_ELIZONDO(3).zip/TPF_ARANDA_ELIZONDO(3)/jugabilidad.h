/*
 * jugabilidad.h
 *
 *  Created on: 22 oct. 2023
 *      Author: lp1-2023
 */

#ifndef JUGABILIDAD_H_
#define JUGABILIDAD_H_

int finDelJuego();
int checkWinner();
int isValid();
int sumAdjacentPips();
int evaluateBoard();
int comeAdyacente();


#endif /* JUGABILIDAD_H_ */

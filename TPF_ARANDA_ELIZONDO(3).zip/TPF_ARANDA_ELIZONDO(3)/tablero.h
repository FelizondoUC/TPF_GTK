/*
 * tablero.h
 *
 *  Created on: 22 oct. 2023
 *      Author: lp1-2023
 */

#ifndef TABLERO_H_
#define TABLERO_H_

void initBoard();
void printBoard();
void boardToMirror();

#endif /* TABLERO_H_ */

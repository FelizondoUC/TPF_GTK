/*
 * computadora.h
 *
 *  Created on: 22 oct. 2023
 *      Author: lp1-2023
 */

#ifndef COMPUTADORA_H_
#define COMPUTADORA_H_

int jugadaAleatoria();
void juegaPc();


#endif /* COMPUTADORA_H_ */
